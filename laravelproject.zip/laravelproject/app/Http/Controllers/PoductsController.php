<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PoductsController extends Controller
{
    /*public function index(){
        $title = "Welcome to ArsenalTech";
        $description = "Web Development Private Ltd...";

        $data = [
            'mobile1' => 'Samsung',
            'mobile2' => 'ASUS'
        ];

        //return view('products.index', compact('title','description'));

        // With Method
            //return view('products.index')->with('title',$title)->with('description',$description);

        return view('products.index', [
            'data' => $data
        ]);
    }*/

    public function index(){
        return view('products.index');
    }

    public function about(){
        return "This is About Page";
    }

    public function show($name){
        $data = [
            'samsung' => 'Samsung',
            'iphone' => 'Apple'
        ];

        return view('products.index',[
            'products' => $data[$name] ?? $name . 'Does not Exist'
        ]);
    }
}
