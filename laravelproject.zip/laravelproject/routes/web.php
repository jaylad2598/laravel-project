<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PoductsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/products', [PoductsController::class, 'index']);

//Route::get('/products/{id}', [PoductsController::class, 'show']);

//Route::get('/products/{id}',
//    [PoductsController::class, 'show'])->where('id','[0-9]+');

//Route::get('/products/{name}', [PoductsController::class, 'show']);

//Route::get('/products/{name}/{id}',
//    [PoductsController::class, 'show'])->where(['name' => '[a-zA-Z]', 'id' => '[0-9]+']);

//Route::get('/products/about', [PoductsController::class, 'about']);

/*
Route::get('/users', function (){
    return 'Welcome to Users....';
});

Route::get('/users', function(){
    return ['PHP','JAVA','Laravel'];
});

Route::get('/users', function(){
    return response()->json(
        [
            'name' => 'Jay',
            'Course' => 'Laravel'
        ]);
    ;
});

Route::get('/users', function(){
    return redirect('/');
});*/

Route::get('/products',[PoductsController::class, 'index'])->name('products');
